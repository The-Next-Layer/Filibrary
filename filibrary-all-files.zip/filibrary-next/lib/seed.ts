export const filamentSeed = [
  {
    "slug": "pla",
    "shortName": "PLA",
    "fullName": "Polylactic Acid",
    "summary": "Easy to print, highly rigid, and affordable, PLA is perfect for decorative items and functional indoor parts that will not face high heat or sustained strain. Its low softening temperature means it can deform under warm ambient conditions or mechanical load.",
    "sourceVideos": [
      "The 5 Filament Types You Need to Know (And What They're Good For)"
    ],
    "videoReferences": [
      {
        "title": "The 5 Filament Types You Need to Know (And What They're Good For)",
        "url": "https://youtu.be/dYPW5Rlwn8g",
        "thumbnailUrl": "https://i.ytimg.com/vi/dYPW5Rlwn8g/hqdefault.jpg"
      }
    ],
    "tags": [
      "Beginner Friendly",
      "Core Material"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      },
      {
        "label": "Polymaker on Amazon",
        "url": "https://www.amazon.com/s?k=Polymaker&geniuslink=true&tag=thenextlayer-20"
      },
      {
        "label": "Prusament",
        "url": "https://www.prusa3d.com/#a_aid=nextlayer"
      },
      {
        "label": "SUNLU",
        "url": "https://www.sunlu.com/?sca_ref=4049874.H3GK5aIQzV"
      },
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": [
      {
        "label": "Strength",
        "value": 74
      },
      {
        "label": "Heat",
        "value": 28
      },
      {
        "label": "Printability",
        "value": 95
      },
      {
        "label": "Weather",
        "value": 24
      },
      {
        "label": "Flex",
        "value": 20
      },
      {
        "label": "Finish",
        "value": 83
      }
    ],
    "statsSource": "Polymaker TDS"
  },
  {
    "slug": "tpu",
    "shortName": "TPU",
    "fullName": "Thermoplastic Polyurethane",
    "summary": "The standard flexible filament, TPU is prized for excellent layer adhesion and impact absorption. It is the go-to choice for seals, bumpers, feet, and soft-touch parts when your extruder can handle flexible materials.",
    "sourceVideos": [
      "The 5 Filament Types You Need to Know (And What They're Good For)"
    ],
    "videoReferences": [
      {
        "title": "The 5 Filament Types You Need to Know (And What They're Good For)",
        "url": "https://youtu.be/dYPW5Rlwn8g",
        "thumbnailUrl": "https://i.ytimg.com/vi/dYPW5Rlwn8g/hqdefault.jpg"
      }
    ],
    "tags": [
      "Beginner Friendly",
      "Core Material",
      "Durable",
      "Flexible",
      "Hygroscopic"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      },
      {
        "label": "Polymaker on Amazon",
        "url": "https://www.amazon.com/s?k=Polymaker&geniuslink=true&tag=thenextlayer-20"
      },
      {
        "label": "Prusament",
        "url": "https://www.prusa3d.com/#a_aid=nextlayer"
      },
      {
        "label": "SUNLU",
        "url": "https://www.sunlu.com/?sca_ref=4049874.H3GK5aIQzV"
      },
      {
        "label": "Fillamentum",
        "url": "https://shop.fillamentum.com/en-in/collections/petg?utm_source=thenextlayer&utm_medium=influencers"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": [
      {
        "label": "Strength",
        "value": 58
      },
      {
        "label": "Heat",
        "value": 48
      },
      {
        "label": "Printability",
        "value": 56
      },
      {
        "label": "Weather",
        "value": 62
      },
      {
        "label": "Flex",
        "value": 98
      },
      {
        "label": "Finish",
        "value": 70
      }
    ],
    "statsSource": "Polymaker TDS"
  },
  {
    "slug": "petg",
    "shortName": "PETG",
    "fullName": "Polyethylene Terephthalate Glycol",
    "summary": "PETG blends strength, flexibility, and decent UV resistance, but it is hygroscopic, stringy, and sometimes annoyingly sticky on beds and nozzles. It remains a very practical functional filament when handled and dried well.",
    "sourceVideos": [
      "The 5 Filament Types You Need to Know (And What They're Good For)"
    ],
    "videoReferences": [
      {
        "title": "The 5 Filament Types You Need to Know (And What They're Good For)",
        "url": "https://youtu.be/dYPW5Rlwn8g",
        "thumbnailUrl": "https://i.ytimg.com/vi/dYPW5Rlwn8g/hqdefault.jpg"
      }
    ],
    "tags": [
      "Beginner Friendly",
      "Core Material",
      "Hygroscopic"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      },
      {
        "label": "Polymaker on Amazon",
        "url": "https://www.amazon.com/s?k=Polymaker&geniuslink=true&tag=thenextlayer-20"
      },
      {
        "label": "Siraya Tech",
        "url": "https://siraya.tech/?sca_ref=9303721.tzUoP2e7D0Hlq5g4"
      },
      {
        "label": "Prusament",
        "url": "https://www.prusa3d.com/#a_aid=nextlayer"
      },
      {
        "label": "SUNLU",
        "url": "https://www.sunlu.com/?sca_ref=4049874.H3GK5aIQzV"
      },
      {
        "label": "Fillamentum",
        "url": "https://shop.fillamentum.com/en-in/collections/petg?utm_source=thenextlayer&utm_medium=influencers"
      },
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": [
      {
        "label": "Strength",
        "value": 72
      },
      {
        "label": "Heat",
        "value": 56
      },
      {
        "label": "Printability",
        "value": 80
      },
      {
        "label": "Weather",
        "value": 58
      },
      {
        "label": "Flex",
        "value": 38
      },
      {
        "label": "Finish",
        "value": 62
      }
    ],
    "statsSource": "Polymaker TDS"
  },
  {
    "slug": "abs",
    "shortName": "ABS",
    "fullName": "Acrylonitrile Butadiene Styrene",
    "summary": "An impact-resistant, high-heat commodity plastic that is excellent for sustained loads and can be vapor-smoothed. It generally wants an enclosure to control warping and fumes.",
    "sourceVideos": [
      "The 5 Filament Types You Need to Know (And What They're Good For)"
    ],
    "videoReferences": [
      {
        "title": "The 5 Filament Types You Need to Know (And What They're Good For)",
        "url": "https://youtu.be/dYPW5Rlwn8g",
        "thumbnailUrl": "https://i.ytimg.com/vi/dYPW5Rlwn8g/hqdefault.jpg"
      }
    ],
    "tags": [
      "Core Material",
      "Durable",
      "High Heat",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      },
      {
        "label": "Polymaker on Amazon",
        "url": "https://www.amazon.com/s?k=Polymaker&geniuslink=true&tag=thenextlayer-20"
      },
      {
        "label": "SUNLU",
        "url": "https://www.sunlu.com/?sca_ref=4049874.H3GK5aIQzV"
      },
      {
        "label": "Fillamentum",
        "url": "https://shop.fillamentum.com/en-in/collections/petg?utm_source=thenextlayer&utm_medium=influencers"
      },
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": [
      {
        "label": "Strength",
        "value": 60
      },
      {
        "label": "Heat",
        "value": 74
      },
      {
        "label": "Printability",
        "value": 50
      },
      {
        "label": "Weather",
        "value": 32
      },
      {
        "label": "Flex",
        "value": 44
      },
      {
        "label": "Finish",
        "value": 70
      }
    ],
    "statsSource": "Polymaker TDS"
  },
  {
    "slug": "asa",
    "shortName": "ASA",
    "fullName": "Acrylonitrile Styrene Acrylate",
    "summary": "ASA offers ABS-like strength and heat resistance with much better UV stability, making it a strong outdoor option. It still benefits from enclosure-friendly printing habits.",
    "sourceVideos": [
      "The 5 Filament Types You Need to Know (And What They're Good For)"
    ],
    "videoReferences": [
      {
        "title": "The 5 Filament Types You Need to Know (And What They're Good For)",
        "url": "https://youtu.be/dYPW5Rlwn8g",
        "thumbnailUrl": "https://i.ytimg.com/vi/dYPW5Rlwn8g/hqdefault.jpg"
      }
    ],
    "tags": [
      "Core Material",
      "High Heat",
      "Outdoor",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      },
      {
        "label": "Polymaker on Amazon",
        "url": "https://www.amazon.com/s?k=Polymaker&geniuslink=true&tag=thenextlayer-20"
      },
      {
        "label": "Prusament",
        "url": "https://www.prusa3d.com/#a_aid=nextlayer"
      },
      {
        "label": "SUNLU",
        "url": "https://www.sunlu.com/?sca_ref=4049874.H3GK5aIQzV"
      },
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": [
      {
        "label": "Strength",
        "value": 70
      },
      {
        "label": "Heat",
        "value": 72
      },
      {
        "label": "Printability",
        "value": 48
      },
      {
        "label": "Weather",
        "value": 96
      },
      {
        "label": "Flex",
        "value": 36
      },
      {
        "label": "Finish",
        "value": 72
      }
    ],
    "statsSource": "Polymaker TDS"
  },
  {
    "slug": "peba",
    "shortName": "PEBA",
    "fullName": "Polyether Block Amide",
    "summary": "PEBA is a durable elastomer with better energy return than standard TPU, so it feels springier and more lively. It suits wearables, flexing mechanisms, and shoe-adjacent parts.",
    "sourceVideos": [
      "7 Specialty Filaments...",
      "STOP 3D Printing PETG..."
    ],
    "videoReferences": [
      {
        "title": "7 Specialty Filaments that Will Revolutionize Your 3D Printing",
        "url": "https://youtu.be/iiwByWHs6UU",
        "thumbnailUrl": "https://i.ytimg.com/vi/iiwByWHs6UU/hqdefault.jpg"
      },
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Durable",
      "Flexible",
      "Hygroscopic"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      },
      {
        "label": "Siraya Tech",
        "url": "https://siraya.tech/?sca_ref=9303721.tzUoP2e7D0Hlq5g4"
      },
      {
        "label": "Fillamentum",
        "url": "https://shop.fillamentum.com/en-in/collections/petg?utm_source=thenextlayer&utm_medium=influencers"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pc-cf",
    "shortName": "PC-CF",
    "fullName": "Carbon Fiber Reinforced Polycarbonate",
    "summary": "PC-CF combines polycarbonate\u2019s heat resistance and strength with carbon fiber\u2019s rigidity and dimensional stability. It is still demanding, but noticeably more manageable than pure PC.",
    "sourceVideos": [
      "7 Specialty Filaments that Will Revolutionize Your 3D Printing"
    ],
    "videoReferences": [
      {
        "title": "7 Specialty Filaments that Will Revolutionize Your 3D Printing",
        "url": "https://youtu.be/iiwByWHs6UU",
        "thumbnailUrl": "https://i.ytimg.com/vi/iiwByWHs6UU/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Composite",
      "High Heat",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "tpe",
    "shortName": "TPE",
    "fullName": "Thermoplastic Elastomer (Chinchilla)",
    "summary": "This very soft TPE is stretchy and skin-safe, making it ideal for soft-touch grips and wearables. Its softness also makes it challenging to feed and print cleanly.",
    "sourceVideos": [
      "7 Specialty Filaments that Will Revolutionize Your 3D Printing"
    ],
    "videoReferences": [
      {
        "title": "7 Specialty Filaments that Will Revolutionize Your 3D Printing",
        "url": "https://youtu.be/iiwByWHs6UU",
        "thumbnailUrl": "https://i.ytimg.com/vi/iiwByWHs6UU/hqdefault.jpg"
      }
    ],
    "tags": [
      "Flexible"
    ],
    "purchaseLinks": [
      {
        "label": "Fillamentum",
        "url": "https://shop.fillamentum.com/en-in/collections/petg?utm_source=thenextlayer&utm_medium=influencers"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pvb",
    "shortName": "PVB",
    "fullName": "Polyvinyl Butyral",
    "summary": "PVB is an aesthetic filament that can be smoothed with isopropyl alcohol for a glassier look. It is interesting for transparent decorative pieces, but moisture sensitivity matters.",
    "sourceVideos": [
      "7 Specialty Filaments that Will Revolutionize Your 3D Printing"
    ],
    "videoReferences": [
      {
        "title": "7 Specialty Filaments that Will Revolutionize Your 3D Printing",
        "url": "https://youtu.be/iiwByWHs6UU",
        "thumbnailUrl": "https://i.ytimg.com/vi/iiwByWHs6UU/hqdefault.jpg"
      }
    ],
    "tags": [
      "Aesthetic",
      "Hygroscopic"
    ],
    "purchaseLinks": [
      {
        "label": "SUNLU",
        "url": "https://www.sunlu.com/?sca_ref=4049874.H3GK5aIQzV"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pp",
    "shortName": "PP",
    "fullName": "Polypropylene",
    "summary": "PP is excellent against chemicals and repeated flexing, but it is notoriously hard to get sticking well. It is a true functional material when you can solve adhesion and warp control.",
    "sourceVideos": [
      "7 Specialty Filaments...",
      "Testing 17 Special-Purpose Filaments..."
    ],
    "videoReferences": [
      {
        "title": "7 Specialty Filaments that Will Revolutionize Your 3D Printing",
        "url": "https://youtu.be/iiwByWHs6UU",
        "thumbnailUrl": "https://i.ytimg.com/vi/iiwByWHs6UU/hqdefault.jpg"
      },
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Chemical Resistant",
      "Core Material",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "cpe",
    "shortName": "CPE",
    "fullName": "Copolyester",
    "summary": "CPE acts like a more engineering-leaning PETG alternative with better heat and impact performance. It also tends to absorb less moisture than PETG.",
    "sourceVideos": [
      "7 Specialty Filaments that Will Revolutionize Your 3D Printing"
    ],
    "videoReferences": [
      {
        "title": "7 Specialty Filaments that Will Revolutionize Your 3D Printing",
        "url": "https://youtu.be/iiwByWHs6UU",
        "thumbnailUrl": "https://i.ytimg.com/vi/iiwByWHs6UU/hqdefault.jpg"
      }
    ],
    "tags": [
      "Chemical Resistant",
      "Durable"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "nonoilen",
    "shortName": "NonOilen",
    "fullName": "Bio-based Food-Contact Polymer",
    "summary": "NonOilen is a bio-based material with food-contact positioning and unusually strong heat resistance for its class. It is compelling for containers, molds, and eco-leaning use cases.",
    "sourceVideos": [
      "7 Specialty Filaments that Will Revolutionize Your 3D Printing"
    ],
    "videoReferences": [
      {
        "title": "7 Specialty Filaments that Will Revolutionize Your 3D Printing",
        "url": "https://youtu.be/iiwByWHs6UU",
        "thumbnailUrl": "https://i.ytimg.com/vi/iiwByWHs6UU/hqdefault.jpg"
      }
    ],
    "tags": [
      "Eco / Bio-Based"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pa6",
    "shortName": "PA6",
    "fullName": "Polyamide 6 (Nylon 6)",
    "summary": "PA6 offers toughness, chemical resistance, and high ductility for parts that take repeated abuse. It is generally stiffer and more moisture-sensitive than PA12.",
    "sourceVideos": [
      "Carbon Fiber 3D Printer Filaments: What Are They Good For?"
    ],
    "videoReferences": [
      {
        "title": "Carbon Fiber 3D Printer Filaments: What Are They Good For?",
        "url": "https://youtu.be/WK-61N-dE8E",
        "thumbnailUrl": "https://i.ytimg.com/vi/WK-61N-dE8E/hqdefault.jpg"
      }
    ],
    "tags": [
      "Chemical Resistant",
      "Durable",
      "High Heat",
      "Hygroscopic",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      },
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pa12",
    "shortName": "PA12",
    "fullName": "Polyamide 12 (Nylon 12)",
    "summary": "PA12 is a durable engineering nylon with lower moisture uptake and greater flexibility than PA6. That makes it a more forgiving nylon family for storage and dimensional stability.",
    "sourceVideos": [
      "Carbon Fiber 3D Printer Filaments: What Are They Good For?"
    ],
    "videoReferences": [
      {
        "title": "Carbon Fiber 3D Printer Filaments: What Are They Good For?",
        "url": "https://youtu.be/WK-61N-dE8E",
        "thumbnailUrl": "https://i.ytimg.com/vi/WK-61N-dE8E/hqdefault.jpg"
      }
    ],
    "tags": [
      "Chemical Resistant",
      "Durable",
      "High Heat",
      "Hygroscopic",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      },
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pc",
    "shortName": "PC",
    "fullName": "Polycarbonate",
    "summary": "PC is one of the toughest common thermoplastics and offers high impact resistance and thermal stability. It is also moisture-sensitive and prone to warping, so machine capability matters a lot.",
    "sourceVideos": [
      "Carbon Fiber 3D Printer Filaments: What Are They Good For?"
    ],
    "videoReferences": [
      {
        "title": "Carbon Fiber 3D Printer Filaments: What Are They Good For?",
        "url": "https://youtu.be/WK-61N-dE8E",
        "thumbnailUrl": "https://i.ytimg.com/vi/WK-61N-dE8E/hqdefault.jpg"
      }
    ],
    "tags": [
      "Durable",
      "High Heat",
      "Hygroscopic",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      },
      {
        "label": "Polymaker on Amazon",
        "url": "https://www.amazon.com/s?k=Polymaker&geniuslink=true&tag=thenextlayer-20"
      },
      {
        "label": "Prusament",
        "url": "https://www.prusa3d.com/#a_aid=nextlayer"
      },
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": [
      {
        "label": "Strength",
        "value": 78
      },
      {
        "label": "Heat",
        "value": 88
      },
      {
        "label": "Printability",
        "value": 36
      },
      {
        "label": "Weather",
        "value": 48
      },
      {
        "label": "Flex",
        "value": 24
      },
      {
        "label": "Finish",
        "value": 66
      }
    ],
    "statsSource": "Polymaker TDS"
  },
  {
    "slug": "pla-cf",
    "shortName": "PLA-CF",
    "fullName": "Carbon Fiber Reinforced PLA",
    "summary": "PLA-CF adds stiffness and a premium matte finish to PLA. It still inherits PLA\u2019s weak heat tolerance, so it is best treated as a rigid aesthetic or prototyping material.",
    "sourceVideos": [
      "Carbon Fiber 3D Printer Filaments: What Are They Good For?"
    ],
    "videoReferences": [
      {
        "title": "Carbon Fiber 3D Printer Filaments: What Are They Good For?",
        "url": "https://youtu.be/WK-61N-dE8E",
        "thumbnailUrl": "https://i.ytimg.com/vi/WK-61N-dE8E/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Aesthetic",
      "Composite"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      },
      {
        "label": "Polymaker on Amazon",
        "url": "https://www.amazon.com/s?k=Polymaker&geniuslink=true&tag=thenextlayer-20"
      },
      {
        "label": "SUNLU",
        "url": "https://www.sunlu.com/?sca_ref=4049874.H3GK5aIQzV"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "petg-cf",
    "shortName": "PETG-CF",
    "fullName": "Carbon Fiber Reinforced PETG",
    "summary": "PETG-CF adds stiffness and extra heat resistance to PETG while improving surface finish. It is a strong, practical composite with nicer dimensional behavior than many advanced materials.",
    "sourceVideos": [
      "Carbon Fiber 3D Printer Filaments: What Are They Good For?"
    ],
    "videoReferences": [
      {
        "title": "Carbon Fiber 3D Printer Filaments: What Are They Good For?",
        "url": "https://youtu.be/WK-61N-dE8E",
        "thumbnailUrl": "https://i.ytimg.com/vi/WK-61N-dE8E/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Aesthetic",
      "Composite"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      },
      {
        "label": "Polymaker on Amazon",
        "url": "https://www.amazon.com/s?k=Polymaker&geniuslink=true&tag=thenextlayer-20"
      },
      {
        "label": "Siraya Tech",
        "url": "https://siraya.tech/?sca_ref=9303721.tzUoP2e7D0Hlq5g4"
      },
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pet-cf",
    "shortName": "PET-CF",
    "fullName": "Carbon Fiber Reinforced PET",
    "summary": "PET-CF pushes the PETG-CF idea a little more toward premium engineering performance. It offers a matte finish, strong stiffness, and good dimensional stability.",
    "sourceVideos": [
      "Carbon Fiber 3D Printer Filaments: What Are They Good For?"
    ],
    "videoReferences": [
      {
        "title": "Carbon Fiber 3D Printer Filaments: What Are They Good For?",
        "url": "https://youtu.be/WK-61N-dE8E",
        "thumbnailUrl": "https://i.ytimg.com/vi/WK-61N-dE8E/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Aesthetic",
      "Composite"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      },
      {
        "label": "Polymaker on Amazon",
        "url": "https://www.amazon.com/s?k=Polymaker&geniuslink=true&tag=thenextlayer-20"
      },
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pa-cf",
    "shortName": "PA-CF",
    "fullName": "Carbon Fiber Reinforced Nylon",
    "summary": "PA-CF trades some impact resistance for huge gains in rigidity, axial strength, and heat resistance. It is one of the strongest practical consumer engineering filaments.",
    "sourceVideos": [
      "Carbon Fiber 3D Printer Filaments: What Are They Good For?"
    ],
    "videoReferences": [
      {
        "title": "Carbon Fiber 3D Printer Filaments: What Are They Good For?",
        "url": "https://youtu.be/WK-61N-dE8E",
        "thumbnailUrl": "https://i.ytimg.com/vi/WK-61N-dE8E/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Chemical Resistant",
      "Composite",
      "Durable",
      "High Heat",
      "Hygroscopic",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      },
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": [
      {
        "label": "Strength",
        "value": 94
      },
      {
        "label": "Heat",
        "value": 86
      },
      {
        "label": "Printability",
        "value": 42
      },
      {
        "label": "Weather",
        "value": 54
      },
      {
        "label": "Flex",
        "value": 16
      },
      {
        "label": "Finish",
        "value": 84
      }
    ],
    "statsSource": "Polymaker / Fiberon TDS"
  },
  {
    "slug": "paht-cf",
    "shortName": "PAHT-CF",
    "fullName": "Carbon Fiber Reinforced High-Temperature Nylon",
    "summary": "PAHT-CF leans even harder into hot-endurance engineering parts with strong rigidity and thermal performance. It is built for serious functional use.",
    "sourceVideos": [
      "Carbon Fiber 3D Printer Filaments: What Are They Good For?"
    ],
    "videoReferences": [
      {
        "title": "Carbon Fiber 3D Printer Filaments: What Are They Good For?",
        "url": "https://youtu.be/WK-61N-dE8E",
        "thumbnailUrl": "https://i.ytimg.com/vi/WK-61N-dE8E/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Chemical Resistant",
      "Composite",
      "High Heat",
      "Hygroscopic",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      },
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "abs-cf",
    "shortName": "ABS-CF",
    "fullName": "Carbon Fiber Reinforced ABS",
    "summary": "ABS-CF blends affordability, durability, and moderate heat resistance while reducing the warping associated with plain ABS. It still benefits from enclosure-friendly printing.",
    "sourceVideos": [
      "Carbon Fiber 3D Printer Filaments: What Are They Good For?"
    ],
    "videoReferences": [
      {
        "title": "Carbon Fiber 3D Printer Filaments: What Are They Good For?",
        "url": "https://youtu.be/WK-61N-dE8E",
        "thumbnailUrl": "https://i.ytimg.com/vi/WK-61N-dE8E/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Composite",
      "High Heat",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "abs-gf",
    "shortName": "ABS-GF",
    "fullName": "Glass Fiber Reinforced ABS",
    "summary": "ABS-GF increases tensile performance and keeps electrical non-conductivity, which makes it useful for housings and tool-oriented parts. It is a strong alternative to ABS-CF.",
    "sourceVideos": [
      "Carbon Fiber 3D Printer Filaments: What Are They Good For?"
    ],
    "videoReferences": [
      {
        "title": "Carbon Fiber 3D Printer Filaments: What Are They Good For?",
        "url": "https://youtu.be/WK-61N-dE8E",
        "thumbnailUrl": "https://i.ytimg.com/vi/WK-61N-dE8E/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Composite",
      "High Heat",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "Siraya Tech",
        "url": "https://siraya.tech/?sca_ref=9303721.tzUoP2e7D0Hlq5g4"
      },
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "hips",
    "shortName": "HIPS",
    "fullName": "High Impact Polystyrene",
    "summary": "HIPS is often discussed as a support pairing, but it is also a very good standalone engineering-ish filament with impact resistance, dielectric strength, and a nice matte finish.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Aesthetic",
      "Durable",
      "Electronics",
      "Support"
    ],
    "purchaseLinks": [
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pctg",
    "shortName": "PCTG",
    "fullName": "Polycyclohexylenedimethylene Terephthalate Glycol",
    "summary": "PCTG is essentially a tougher, clearer, more chemically and thermally capable PETG-style material. It keeps much of PETG\u2019s practicality while improving durability.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Beginner Friendly",
      "Chemical Resistant",
      "Durable",
      "High Heat"
    ],
    "purchaseLinks": [
      {
        "label": "Fillamentum",
        "url": "https://shop.fillamentum.com/en-in/collections/petg?utm_source=thenextlayer&utm_medium=influencers"
      },
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "peba-air",
    "shortName": "PEBA Air",
    "fullName": "Foaming Polyether Block Amide",
    "summary": "PEBA Air uses a foaming agent to reduce density and alter feel, giving a more premium foam-like response. It is interesting for footwear, cushioning, and soft technical parts.",
    "sourceVideos": [
      "STOP 3D Printing PETG...",
      "Testing 17 Special-Purpose Filaments..."
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      },
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Flexible",
      "Hygroscopic",
      "Lightweight"
    ],
    "purchaseLinks": [
      {
        "label": "Siraya Tech",
        "url": "https://siraya.tech/?sca_ref=9303721.tzUoP2e7D0Hlq5g4"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "tpu-air",
    "shortName": "TPU Air",
    "fullName": "Foaming Thermoplastic Polyurethane",
    "summary": "TPU Air softens and lightens the printed result while staying in the TPU family. It works well for grips, padding, and lightweight soft-touch parts.",
    "sourceVideos": [
      "STOP 3D Printing PETG...",
      "Testing 17 Special-Purpose Filaments..."
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      },
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Flexible",
      "Hygroscopic",
      "Lightweight"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "roamr",
    "shortName": "ROAMR",
    "fullName": "Foaming Performance Elastomer",
    "summary": "ROAMR is a foamed flexible material aimed at premium performance applications where rebound and low density matter. It targets wearable and shoe-adjacent parts more directly than standard TPU.",
    "sourceVideos": [
      "STOP 3D Printing PETG...",
      "Testing 17 Special-Purpose Filaments..."
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      },
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Flexible",
      "Hygroscopic"
    ],
    "purchaseLinks": [
      {
        "label": "Siraya Tech",
        "url": "https://siraya.tech/?sca_ref=9303721.tzUoP2e7D0Hlq5g4"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "morphlex",
    "shortName": "Morphlex",
    "fullName": "Shoe-Oriented Elastomer",
    "summary": "Morphlex is designed around easier shoe printing by feeding stiffer but printing softer. It can work very well, but geometry and perimeter strategy matter.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Flexible"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "fishy-pa6",
    "shortName": "Fishy PA6",
    "fullName": "Ocean-Recycled Nylon 6",
    "summary": "Fishy PA6 is recycled from fishing nets and keeps the practical toughness and heat resistance of nylon 6. It brings a compelling recycled-material story to engineering prints.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Durable",
      "Eco / Bio-Based"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "orca",
    "shortName": "OrCA",
    "fullName": "Ocean-Recycled Carbon Fiber Nylon",
    "summary": "OrCA adds carbon fiber to the ocean-recycled nylon concept for more rigidity and creep resistance. It is the more structural sibling to Fishy PA6.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Eco / Bio-Based"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "petg-ptfe",
    "shortName": "PETG-PTFE",
    "fullName": "PETG with Polytetrafluoroethylene",
    "summary": "PETG-PTFE lowers surface friction for sliding parts and moving interfaces. It is especially interesting for hubs, guides, and low-friction mechanisms.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "antibacterial-cpe",
    "shortName": "Antibacterial CPE",
    "fullName": "Silver Nanoparticle Copolyester",
    "summary": "Antibacterial CPE uses antimicrobial additives to suit hygiene-oriented environments like kitchens, labs, and shared public-touch objects.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Chemical Resistant"
    ],
    "purchaseLinks": [
      {
        "label": "Siraya Tech",
        "url": "https://siraya.tech/?sca_ref=9303721.tzUoP2e7D0Hlq5g4"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "petg-magnetite",
    "shortName": "PETG-Magnetite",
    "fullName": "Magnetite-Filled PETG",
    "summary": "PETG-Magnetite is a heavy, magnet-responsive specialty filament useful for switches, weighted parts, and unusual electromechanical experiments.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Composite",
      "Specialty"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "asa-cf",
    "shortName": "ASA-CF",
    "fullName": "Carbon Fiber Reinforced ASA",
    "summary": "ASA-CF boosts rigidity and dimensional stability while preserving ASA\u2019s outdoor advantages. It is a strong candidate for premium outdoor functional parts.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Aesthetic",
      "Composite",
      "High Heat",
      "Outdoor",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": [
      {
        "label": "Strength",
        "value": 82
      },
      {
        "label": "Heat",
        "value": 78
      },
      {
        "label": "Printability",
        "value": 58
      },
      {
        "label": "Weather",
        "value": 92
      },
      {
        "label": "Flex",
        "value": 22
      },
      {
        "label": "Finish",
        "value": 86
      }
    ],
    "statsSource": "Polymaker Fiberon TDS"
  },
  {
    "slug": "asa-gf",
    "shortName": "ASA-GF",
    "fullName": "Glass Fiber Reinforced ASA",
    "summary": "ASA-GF delivers strong outdoor and heat performance while staying electrically non-conductive. It is a practical composite for outdoor engineering parts.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Composite",
      "High Heat",
      "Outdoor",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pla-ht",
    "shortName": "PLA-HT",
    "fullName": "High-Temperature PLA",
    "summary": "PLA-HT prints like friendly PLA but can handle significantly more heat, especially after annealing. It is one of the easiest ways to step up from ordinary PLA heat limits.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Beginner Friendly",
      "High Heat"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      },
      {
        "label": "colorFabb",
        "url": "https://colorfabb.us/catalogsearch/result/?q=LW-ASA#u45"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pla-ht-gf",
    "shortName": "PLA-HT-GF",
    "fullName": "Glass Fiber Reinforced High-Temperature PLA",
    "summary": "PLA-HT-GF adds more rigidity and engineering flavor to PLA-HT. It is an approachable route to higher-heat parts without fully jumping into enclosure-heavy materials.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Composite",
      "High Heat"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pps-tf",
    "shortName": "PPS-TF",
    "fullName": "Tribology-Grade PPS Composite",
    "summary": "PPS-TF sits deep in engineering-polymer territory with high heat, chemical resistance, and wear performance. It usually requires serious machine capability.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Chemical Resistant",
      "High Heat",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "ppa-cf",
    "shortName": "PPA-CF",
    "fullName": "Carbon Fiber Reinforced PPA",
    "summary": "PPA-CF combines strength, heat resistance, and rigidity in a very aggressive engineering package. It is one of the closest consumer options to almost metal-like stiffness.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Chemical Resistant",
      "Composite",
      "High Heat",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "Siraya Tech",
        "url": "https://siraya.tech/?sca_ref=9303721.tzUoP2e7D0Hlq5g4"
      },
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pps-cf",
    "shortName": "PPS-CF",
    "fullName": "Carbon Fiber Reinforced PPS",
    "summary": "PPS-CF pushes into industrial territory with exceptional chemical, flame, and thermal resistance. It is difficult but extremely capable.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Chemical Resistant",
      "Composite",
      "High Heat",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pps-gf",
    "shortName": "PPS-GF",
    "fullName": "Glass Fiber Reinforced PPS",
    "summary": "PPS-GF targets demanding industrial environments with excellent heat and chemical resistance while favoring glass-fiber electrical behavior.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Chemical Resistant",
      "Composite",
      "High Heat",
      "Print Enclosed"
    ],
    "purchaseLinks": [
      {
        "label": "3DXTECH",
        "url": "https://www.3dxtech.com/?sca_ref=7992337.FNGNSNu3XtMmGG4X"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "fibreheart-abs-ht-hf",
    "shortName": "Fibreheart ABS HT HF",
    "fullName": "High-Temperature High-Flow ABS",
    "summary": "This ABS formulation aims for high speed and about 101\u00b0C temperature endurance, making it attractive for hot environments and heated-printer interiors.",
    "sourceVideos": [
      "STOP 3D Printing PETG! Try THESE Filaments Instead!"
    ],
    "videoReferences": [
      {
        "title": "STOP 3D Printing PETG! Try THESE Filaments Instead!",
        "url": "https://youtu.be/_0IUm5Ac9ZM",
        "thumbnailUrl": "https://i.ytimg.com/vi/_0IUm5Ac9ZM/hqdefault.jpg"
      }
    ],
    "tags": [
      "High Heat",
      "Specialty"
    ],
    "purchaseLinks": [
      {
        "label": "Siraya Tech",
        "url": "https://siraya.tech/?sca_ref=9303721.tzUoP2e7D0Hlq5g4"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "grip-tpu",
    "shortName": "GRIP TPU",
    "fullName": "High-Traction Thermoplastic Polyurethane",
    "summary": "GRIP TPU is explicitly designed to be grippier than standard TPU while still printing nicely. It is well suited for handles, feet, and traction-focused parts.",
    "sourceVideos": [
      "Testing 17 Special-Purpose Filaments for YOUR Next Project!"
    ],
    "videoReferences": [
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Aesthetic",
      "Flexible"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pha",
    "shortName": "PHA",
    "fullName": "Polyhydroxyalkanoate (AllPHA)",
    "summary": "PHA is a bio-based, biodegradable material that prints somewhat like PLA but brings odor and bed-adhesion quirks. It is especially interesting for eco-focused projects.",
    "sourceVideos": [
      "Testing 17 Special-Purpose Filaments for YOUR Next Project!"
    ],
    "videoReferences": [
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Eco / Bio-Based"
    ],
    "purchaseLinks": [
      {
        "label": "colorFabb",
        "url": "https://colorfabb.us/catalogsearch/result/?q=LW-ASA#u45"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "lw-pla",
    "shortName": "LW-PLA",
    "fullName": "Lightweight Foaming PLA",
    "summary": "LW-PLA uses foaming to dramatically reduce weight and create a balsa-like texture. It is a classic fit for RC aircraft and gram-sensitive builds.",
    "sourceVideos": [
      "Testing 17 Special-Purpose Filaments for YOUR Next Project!"
    ],
    "videoReferences": [
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Beginner Friendly",
      "Lightweight"
    ],
    "purchaseLinks": [
      {
        "label": "colorFabb",
        "url": "https://colorfabb.us/catalogsearch/result/?q=LW-ASA#u45"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "lw-asa",
    "shortName": "LW-ASA",
    "fullName": "Lightweight Foaming ASA",
    "summary": "LW-ASA applies the same weight-saving trick to an outdoor-capable engineering plastic. It is compelling for lightweight, UV-stable parts.",
    "sourceVideos": [
      "Testing 17 Special-Purpose Filaments for YOUR Next Project!"
    ],
    "videoReferences": [
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "High Heat",
      "Lightweight",
      "Outdoor"
    ],
    "purchaseLinks": [
      {
        "label": "colorFabb",
        "url": "https://colorfabb.us/catalogsearch/result/?q=LW-ASA#u45"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pc-space-grade",
    "shortName": "PC Space Grade",
    "fullName": "Low-Outgassing ESD-Safe Polycarbonate",
    "summary": "PC Space Grade is a specialty polycarbonate aimed at sensitive electronics and harsh environments, with low-outgassing and ESD-friendly positioning.",
    "sourceVideos": [
      "Testing 17 Special-Purpose Filaments for YOUR Next Project!"
    ],
    "videoReferences": [
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Electronics",
      "High Heat",
      "Specialty"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "abs-v0",
    "shortName": "ABS V0",
    "fullName": "UL94 V0 Flame-Retardant ABS",
    "summary": "ABS V0 targets electronics-friendly applications by adding strong flame-retardant behavior while preserving familiar ABS-style print behavior.",
    "sourceVideos": [
      "Testing 17 Special-Purpose Filaments for YOUR Next Project!"
    ],
    "videoReferences": [
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Electronics",
      "High Heat",
      "Print Enclosed",
      "Specialty"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "polycast",
    "shortName": "PolyCast",
    "fullName": "Casting Filament",
    "summary": "PolyCast is engineered to burn out cleanly for casting workflows. It makes metal casting geometries more accessible to makers.",
    "sourceVideos": [
      "Testing 17 Special-Purpose Filaments for YOUR Next Project!"
    ],
    "videoReferences": [
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Specialty"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "hdpe",
    "shortName": "HDPE",
    "fullName": "High-Density Polyethylene",
    "summary": "HDPE is famous for chemical resistance and resilience, and newer formulations make it somewhat more printable than old-school HDPE expectations.",
    "sourceVideos": [
      "Testing 17 Special-Purpose Filaments for YOUR Next Project!"
    ],
    "videoReferences": [
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Chemical Resistant"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "petg-tungsten",
    "shortName": "PETG-Tungsten",
    "fullName": "Tungsten-Filled PETG",
    "summary": "PETG-Tungsten is a dense specialty filament for shielding-style applications where mass and attenuation matter.",
    "sourceVideos": [
      "Testing 17 Special-Purpose Filaments for YOUR Next Project!"
    ],
    "videoReferences": [
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Composite",
      "Specialty"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "copa",
    "shortName": "CoPA",
    "fullName": "Copolyamide (Nylon 6 / 6.6)",
    "summary": "CoPA blends nylon families for strong tensile performance and high heat while remaining surprisingly printable. It is an appealing engineering nylon for less dramatic setups.",
    "sourceVideos": [
      "Testing 17 Special-Purpose Filaments for YOUR Next Project!"
    ],
    "videoReferences": [
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Chemical Resistant",
      "High Heat",
      "Hygroscopic"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "tpu-gf",
    "shortName": "TPU-GF",
    "fullName": "Glass Fiber Reinforced TPU",
    "summary": "TPU-GF mixes impact absorption with glass-fiber rigidity and a changed surface texture. It is a very unusual flexible composite that rewards thoughtful design.",
    "sourceVideos": [
      "Testing 17 Special-Purpose Filaments for YOUR Next Project!"
    ],
    "videoReferences": [
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Aesthetic",
      "Composite",
      "Durable",
      "Flexible"
    ],
    "purchaseLinks": [
      {
        "label": "Siraya Tech",
        "url": "https://siraya.tech/?sca_ref=9303721.tzUoP2e7D0Hlq5g4"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pla-support",
    "shortName": "PLA Support",
    "fullName": "Breakaway PLA Support Material",
    "summary": "PLA Support makes support removal easier for PLA-centric prints without needing a soluble material. It is best where access is straightforward.",
    "sourceVideos": [
      "Testing 17 Special-Purpose Filaments for YOUR Next Project!"
    ],
    "videoReferences": [
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Support"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "pva",
    "shortName": "PVA",
    "fullName": "Water-Soluble Support Material",
    "summary": "PVA is a dissolvable support material ideal for internal cavities and complex geometry. Moisture management is a big part of using it well.",
    "sourceVideos": [
      "Testing 17 Special-Purpose Filaments for YOUR Next Project!"
    ],
    "videoReferences": [
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Hygroscopic",
      "Support"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      },
      {
        "label": "Prusament",
        "url": "https://www.prusa3d.com/#a_aid=nextlayer"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "polysupport-pa",
    "shortName": "PolySupport PA",
    "fullName": "Nylon Support Interface Material",
    "summary": "PolySupport PA is designed specifically to work with nylon families that are annoying to support. It solves a very practical engineering-print problem.",
    "sourceVideos": [
      "Testing 17 Special-Purpose Filaments for YOUR Next Project!"
    ],
    "videoReferences": [
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Support"
    ],
    "purchaseLinks": [
      {
        "label": "Polymaker",
        "url": "https://shop.polymaker.com/?aff=457"
      }
    ],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "abs-kevlar",
    "shortName": "ABS Kevlar",
    "fullName": "Kevlar Reinforced ABS",
    "summary": "ABS Kevlar adds impact-oriented reinforcement with less nozzle wear and a different feel than carbon-fiber blends. It is a nice alternative in some rugged applications.",
    "sourceVideos": [
      "Testing 17 Special-Purpose Filaments for YOUR Next Project!"
    ],
    "videoReferences": [
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Abrasive",
      "Composite",
      "Durable",
      "Print Enclosed"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  },
  {
    "slug": "petg-ultra-glow",
    "shortName": "PETG Ultra-Glow",
    "fullName": "Glow-in-the-Dark PETG",
    "summary": "PETG Ultra-Glow is a genuinely functional glow material for visibility and safety rather than just novelty. It works for signage and emergency-style markers.",
    "sourceVideos": [
      "Testing 17 Special-Purpose Filaments for YOUR Next Project!"
    ],
    "videoReferences": [
      {
        "title": "Testing 17 Special-Purpose Filaments for YOUR Next Project!",
        "url": "https://youtu.be/V-lEyazyaTM",
        "thumbnailUrl": "https://i.ytimg.com/vi/V-lEyazyaTM/hqdefault.jpg"
      }
    ],
    "tags": [
      "Specialty"
    ],
    "purchaseLinks": [],
    "heroImageUrl": "",
    "heroImageCreditLabel": "",
    "heroImageCreditUrl": "",
    "stats": null,
    "statsSource": null
  }
] as const;
